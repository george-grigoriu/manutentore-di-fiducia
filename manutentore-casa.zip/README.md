# Manutentore Casa - Fullstack (Starter)

## Struttura
- backend/ : Express + better-sqlite3 API
- frontend/ : React + Vite UI

## Istruzioni rapide

### Backend
```
cd backend
npm install
cp .env.example .env
node server.js
```
Il server creerà il DB e le tabelle automaticamente.

### Frontend
```
cd frontend
npm install
npm run dev
```

### Note
- Prezzi e saldi sono in **cent** (es. 10000 = 100.00 €).
- Admin: crea un user e aggiorna la colonna `role` a `admin` via sqlite3 o endpoint.
- In produzione integra Stripe con webhooks verificati per confermare i pagamenti prima di distribuire fondi.
