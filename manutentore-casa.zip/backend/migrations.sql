PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT DEFAULT 'user',
  wallet_balance INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  customer_id INTEGER NOT NULL,
  pro_id INTEGER,
  price INTEGER,
  status TEXT DEFAULT 'open',
  created_at DATETIME DEFAULT (datetime('now')),
  FOREIGN KEY(customer_id) REFERENCES users(id),
  FOREIGN KEY(pro_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  amount INTEGER NOT NULL,
  type TEXT NOT NULL,
  metadata TEXT,
  created_at DATETIME DEFAULT (datetime('now')),
  FOREIGN KEY(user_id) REFERENCES users(id)
);
