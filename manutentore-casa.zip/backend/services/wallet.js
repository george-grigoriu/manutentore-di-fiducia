const db = require('../db');

function creditUser(userId, amount, metadata = '') {
  const stmt = db.prepare('UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?');
  stmt.run(amount, userId);
  const t = db.prepare('INSERT INTO transactions (user_id, amount, type, metadata) VALUES (?, ?, ?, ?)');
  t.run(userId, amount, 'topup', metadata);
}

function debitUser(userId, amount, metadata = '') {
  const user = db.prepare('SELECT wallet_balance FROM users WHERE id = ?').get(userId);
  if (!user || user.wallet_balance < amount) throw new Error('Insufficient balance');
  db.prepare('UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?').run(amount, userId);
  db.prepare('INSERT INTO transactions (user_id, amount, type, metadata) VALUES (?, ?, ?, ?)').run(userId, -amount, 'debit', metadata);
}

function getBalance(userId) {
  const r = db.prepare('SELECT wallet_balance FROM users WHERE id = ?').get(userId);
  return r ? r.wallet_balance : 0;
}

module.exports = { creditUser, debitUser, getBalance };
