const express = require('express');
const db = require('../db');
const jwt = require('jsonwebtoken');
const { creditUser, debitUser } = require('../services/wallet');
const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'secret_dev';

// use a transaction to ensure atomicity
function authMiddleware(req, res, next) {
  const auth = req.headers.authorization; if (!auth) return res.status(401).json({ error: 'no token' });
  const token = auth.replace('Bearer ', '');
  try { req.user = jwt.verify(token, JWT_SECRET); next(); } catch (err) { res.status(401).json({ error: 'invalid token' }); }
}

router.post('/pay-job', authMiddleware, (req, res) => {
  try {
    const { jobId, paymentMethod } = req.body;
    if (!jobId) return res.status(400).json({ error: 'jobId required' });

    const job = db.prepare('SELECT * FROM jobs WHERE id = ?').get(jobId);
    if (!job) return res.status(404).json({ error: 'Job not found' });
    if (job.customer_id !== req.user.id) return res.status(403).json({ error: 'not your job' });

    const price = Number(job.price || 0);
    if (price <= 0) return res.status(400).json({ error: 'job has no price' });

    const commissionRate = 0.20;
    const commission = Math.round(price * commissionRate);
    const proAmount = price - commission;

    const trx = db.transaction(() => {
      if (paymentMethod === 'wallet') {
        const customer = db.prepare('SELECT wallet_balance FROM users WHERE id = ?').get(req.user.id);
        if (!customer || customer.wallet_balance < price) throw new Error('Insufficient wallet balance');
        db.prepare('UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?').run(price, req.user.id);
        db.prepare('INSERT INTO transactions (user_id, amount, type, metadata) VALUES (?, ?, ?, ?)').run(req.user.id, -price, 'job_payment', `Paid job ${jobId}`);
      } else {
        // external payment assumed succeeded; log job_payment with negative amount for customer
        db.prepare('INSERT INTO transactions (user_id, amount, type, metadata) VALUES (?, ?, ?, ?)').run(req.user.id, -price, 'job_payment', `Paid job ${jobId} via external`);
      }

      if (!job.pro_id) throw new Error('No professional assigned to this job');

      // credit pro
      db.prepare('UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?').run(proAmount, job.pro_id);
      db.prepare('INSERT INTO transactions (user_id, amount, type, metadata) VALUES (?, ?, ?, ?)').run(job.pro_id, proAmount, 'pro_credit', `Pro credit job ${jobId}`);

      // record commission under user_id = 0 (platform)
      db.prepare('INSERT INTO transactions (user_id, amount, type, metadata) VALUES (?, ?, ?, ?)').run(0, commission, 'commission', `Commission job ${jobId}`);

      // update job status
      db.prepare('UPDATE jobs SET status = ? WHERE id = ?').run('completed', jobId);
    });

    trx();

    return res.json({ ok: true, jobId, price, commission, proAmount });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message || 'server error' });
  }
});

module.exports = router;
