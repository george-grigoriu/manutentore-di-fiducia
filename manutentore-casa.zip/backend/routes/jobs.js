const express = require('express');
const db = require('../db');
const jwt = require('jsonwebtoken');
const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'secret_dev';

function authMiddleware(req, res, next) {
  const auth = req.headers.authorization; if (!auth) return res.status(401).json({ error: 'no token' });
  const token = auth.replace('Bearer ', '');
  try { req.user = jwt.verify(token, JWT_SECRET); next(); } catch (err) { res.status(401).json({ error: 'invalid token' }); }
}

// list open jobs
router.get('/', (req, res) => {
  const rows = db.prepare('SELECT j.*, u.name as customer_name FROM jobs j JOIN users u ON u.id = j.customer_id ORDER BY created_at DESC').all();
  res.json(rows);
});

// create job (customer)
router.post('/', authMiddleware, (req, res) => {
  const { title, description, price } = req.body;
  const stmt = db.prepare('INSERT INTO jobs (title, description, customer_id, price) VALUES (?, ?, ?, ?)');
  const info = stmt.run(title, description, req.user.id, price || 0);
  const job = db.prepare('SELECT * FROM jobs WHERE id = ?').get(info.lastInsertRowid);
  res.json(job);
});

// accept job (professional)
router.post('/:id/accept', authMiddleware, (req, res) => {
  const id = req.params.id;
  const job = db.prepare('SELECT * FROM jobs WHERE id = ?').get(id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  if (job.status !== 'open') return res.status(400).json({ error: 'Job not open' });
  db.prepare('UPDATE jobs SET pro_id = ?, status = ? WHERE id = ?').run(req.user.id, 'accepted', id);
  res.json({ ok: true });
});

module.exports = router;
