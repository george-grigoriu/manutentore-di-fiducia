const express = require('express');
const db = require('../db');
const jwt = require('jsonwebtoken');
const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'secret_dev';

function adminOnly(req, res, next) {
  const auth = req.headers.authorization; if (!auth) return res.status(401).json({ error: 'no token' });
  const token = auth.replace('Bearer ', '');
  try { const data = jwt.verify(token, JWT_SECRET); if (data.role !== 'admin') return res.status(403).json({ error: 'forbidden' }); req.user = data; next(); } catch (err) { res.status(401).json({ error: 'invalid token' }); }
}

router.get('/users', adminOnly, (req, res) => {
  const rows = db.prepare('SELECT id, name, email, role, wallet_balance, created_at FROM users ORDER BY id DESC').all();
  res.json(rows);
});

router.get('/jobs', adminOnly, (req, res) => {
  const rows = db.prepare('SELECT * FROM jobs ORDER BY created_at DESC').all();
  res.json(rows);
});

router.post('/credit', adminOnly, (req, res) => {
  const { userId, amount } = req.body;
  if (!userId || !amount) return res.status(400).json({ error: 'userId & amount required' });
  db.prepare('UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?').run(amount, userId);
  db.prepare('INSERT INTO transactions (user_id, amount, type, metadata) VALUES (?, ?, ?, ?)').run(userId, amount, 'admin_credit', 'admin topup');
  res.json({ ok: true });
});

// earnings summary
router.get('/earnings', adminOnly, (req, res) => {
  const totalCommissionRow = db.prepare("SELECT SUM(amount) as total_commission FROM transactions WHERE type = 'commission'").get();
  const totalCommission = totalCommissionRow ? Number(totalCommissionRow.total_commission || 0) : 0;
  const totalVolumeRow = db.prepare("SELECT SUM(-amount) as total_volume FROM transactions WHERE type = 'job_payment'").get();
  const totalVolume = totalVolumeRow ? Number(totalVolumeRow.total_volume || 0) : 0;
  const completedJobsRow = db.prepare("SELECT COUNT(*) as completed_jobs FROM jobs WHERE status = 'completed'").get();
  const completedJobs = completedJobsRow ? completedJobsRow.completed_jobs : 0;
  res.json({ totalCommission, totalVolume, completedJobs });
});

module.exports = router;
