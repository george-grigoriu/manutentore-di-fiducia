import React, { useState, useEffect } from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Auth from './pages/Auth'
import AdminDashboard from './pages/AdminDashboard'
import PayJob from './pages/PayJob'
import AdminEarnings from './pages/AdminEarnings'
import api from './api'

export default function App(){
  const [user, setUser] = useState(null);
  useEffect(()=>{
    const token = localStorage.getItem('token');
    if (token) { api.addAuth(token); api.get('/auth/me').then(r=> setUser(r.data.user)).catch(()=>{}); }
  },[])
  return (
    <div className="container">
      <header className="header">
        <h2><Link to="/">Manutentore Casa</Link></h2>
        <nav>
          <Link to="/">Home</Link> | <Link to="/auth">Accedi</Link> | <Link to="/admin">Admin</Link>
        </nav>
      </header>
      <Routes>
        <Route path="/" element={<Home user={user} />} />
        <Route path="/auth" element={<Auth onAuth={(u, token)=>{localStorage.setItem('token', token); api.addAuth(token); setUser(u);}}/>} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/pay/:id" element={<PayJob />} />
        <Route path="/admin/earnings" element={<AdminEarnings />} />
      </Routes>
    </div>
  )
}
