import React, { useState } from 'react'
import api from '../api'

export default function Auth({ onAuth }){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [name,setName]=useState('');
  const register = async ()=>{
    const res = await api.post('/auth/register', { name, email, password });
    onAuth(res.data.user, res.data.token);
  }
  const login = async ()=>{
    const res = await api.post('/auth/login', { email, password });
    onAuth(res.data.user, res.data.token);
  }
  return (
    <div>
      <h3>Auth</h3>
      <div className="card">
        <input placeholder="Nome" value={name} onChange={e=>setName(e.target.value)} />
        <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <div style={{marginTop:8}}>
          <button onClick={login}>Login</button>
          <button onClick={register} style={{marginLeft:8}}>Registrati</button>
        </div>
      </div>
    </div>
  )
}
