import React, { useEffect, useState } from 'react'
import api from '../api'
import { Link } from 'react-router-dom'

export default function Home(){
  const [jobs, setJobs] = useState([]);
  useEffect(()=>{ api.get('/jobs').then(r=> setJobs(r.data)); },[]);
  return (
    <div>
      <h3>Offerte</h3>
      {jobs.map(j=> (
        <div className="card" key={j.id}>
          <h4>{j.title} — {j.price ? `${(j.price/100).toFixed(2)}€` : '—'}</h4>
          <p>{j.description}</p>
          <small>Cliente: {j.customer_name}</small>
          <div style={{marginTop:8}}>
            {j.pro_id ? <em>Assegnato</em> : <Link to={`/pay/${j.id}`}>Paga / Vedi</Link>}
          </div>
        </div>
      ))}
    </div>
  )
}
