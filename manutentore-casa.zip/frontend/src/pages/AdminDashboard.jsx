import React, { useEffect, useState } from 'react'
import api from '../api'
import { Link } from 'react-router-dom'

export default function AdminDashboard(){
  const [users,setUsers]=useState([]);
  useEffect(()=>{ const token = localStorage.getItem('token'); if (!token) return; api.addAuth(token); api.get('/admin/users').then(r=> setUsers(r.data)).catch(()=>{}); },[]);
  return (
    <div>
      <h3>Admin Dashboard</h3>
      <Link to="/admin/earnings">Vedi entrate</Link>
      {users.map(u=> (
        <div className="card" key={u.id}>
          <b>{u.name}</b> — {u.email} — {u.role} — {u.wallet_balance/100}€
        </div>
      ))}
    </div>
  )
}
