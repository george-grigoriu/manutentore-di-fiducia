import React, { useEffect, useState } from 'react';
import api from '../api';
import { useParams } from 'react-router-dom';

export default function PayJob(){
  const { id } = useParams();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(false);
  const [method, setMethod] = useState('stripe');
  const [message, setMessage] = useState('');

  useEffect(()=> {
    api.get('/jobs').then(r=> {
      const found = r.data.find(j=> String(j.id) === String(id));
      setJob(found);
    });
  }, [id]);

  async function handlePay() {
    setLoading(true); setMessage('');
    try {
      const token = localStorage.getItem('token'); if (!token) throw new Error('not auth');
      api.addAuth(token);
      const res = await api.post('/payments/pay-job', { jobId: job.id, paymentMethod: method });
      if (res.data.ok) {
        setMessage(`Pagamento effettuato. Commissione: ${(res.data.commission/100).toFixed(2)}€, Pro accredito: ${(res.data.proAmount/100).toFixed(2)}€`);
      }
    } catch (err) {
      console.error(err);
      setMessage(err?.response?.data?.error || err.message);
    } finally { setLoading(false); }
  }

  if (!job) return <div>Caricamento...</div>
  return (
    <div className="card">
      <h4>Paga lavoro: {job.title} — {job.price ? `${(job.price/100).toFixed(2)}€` : '—'}</h4>
      <div>
        <label>
          <input type="radio" checked={method==='stripe'} onChange={()=>setMethod('stripe')} /> Carta (Stripe simulato)
        </label>
        <label style={{marginLeft:12}}>
          <input type="radio" checked={method==='wallet'} onChange={()=>setMethod('wallet')} /> Usa Wallet
        </label>
      </div>
      <div style={{marginTop:8}}>
        <button onClick={handlePay} disabled={loading}>{loading ? '...' : 'Paga'}</button>
      </div>
      {message && <div style={{marginTop:8}}>{message}</div>}
    </div>
  );
}
