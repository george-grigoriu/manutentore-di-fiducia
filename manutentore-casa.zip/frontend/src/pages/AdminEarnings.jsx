import React, { useEffect, useState } from 'react';
import api from '../api';

export default function AdminEarnings(){
  const [data, setData] = useState(null);
  useEffect(()=>{
    const t = localStorage.getItem('token');
    if (!t) return;
    api.addAuth(t);
    api.get('/admin/earnings').then(r=> setData(r.data)).catch(e=> console.error(e));
  },[]);
  if (!data) return <div>Caricamento...</div>;
  return (
    <div>
      <h3>Entrate Piattaforma</h3>
      <div className="card">Totale commissioni: <b>{(data.totalCommission/100).toFixed(2)} €</b></div>
      <div className="card">Volume pagamenti: <b>{(data.totalVolume/100).toFixed(2)} €</b></div>
      <div className="card">Lavori completati: <b>{data.completedJobs}</b></div>
    </div>
  );
}
