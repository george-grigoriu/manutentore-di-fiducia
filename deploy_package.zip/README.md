
# Deploy completo backend + frontend

## Prerequisiti

- Git installato  
- Node.js e npm installati  
- Account Heroku ([heroku.com](https://heroku.com))  
- Account Netlify ([netlify.com](https://netlify.com))  
- Heroku CLI installato:  
  ```bash
  npm install -g heroku
  heroku login
  ```

---

## Backend (Express + SQLite)

### 1. Configurazione

- Nel backend (`/app/backend/`) aggiungi un file `Procfile` con il contenuto:  
  ```
  web: node server.js
  ```

- Modifica `server.js` per leggere la porta da environment variable:  
  ```js
  const PORT = process.env.PORT || 4000;
  ```

- Assicurati che in `package.json` ci sia lo script start:  
  ```json
  "scripts": {
    "start": "node server.js"
  }
  ```

- Aggiungi `.gitignore` con almeno queste righe:  
  ```
  node_modules
  data.db
  .env
  ```

---

### 2. Git & Deploy su Heroku

```bash
cd /app/backend/
git init
git add .
git commit -m "Backend ready for deploy"
heroku create nome-tuo-app-backend
git push heroku main
```

- Verifica il backend su:  
  ```
  https://nome-tuo-app-backend.herokuapp.com/
  ```

---

## Frontend (React)

### 1. Configurazione

- Nel frontend (`/app/frontend/`) imposta in `package.json` la homepage:  
  ```json
  "homepage": "."
  ```

- Modifica le chiamate API in frontend per puntare al backend su Heroku, ad esempio:  
  ```js
  const API_URL = "https://nome-tuo-app-backend.herokuapp.com/api";
  ```

### 2. Build & Deploy su Netlify

```bash
cd /app/frontend/
npm run build
```

- Vai su [Netlify](https://app.netlify.com/)  
- Crea un nuovo sito, collegalo al tuo repo git o carica la cartella `build` manualmente  
- Configura build command: `npm run build`  
- Cartella pubblica: `build`  
- Esegui il deploy  

---

### 3. Test

- Visita il sito Netlify per verificare che la app funzioni correttamente, inclusa la sezione admin.

---

## Note sul Database

- SQLite in Heroku non è persistente, usa filesystem temporaneo  
- Per produzione, valuta un database esterno come PostgreSQL (addon Heroku) o MongoDB Atlas  

---

## Comandi rapidi

```bash
# Backend
cd /app/backend/
git init
heroku create nome-tuo-app-backend
git push heroku main

# Frontend
cd /app/frontend/
npm run build
# deploy su Netlify via UI o CLI
```

---

Se vuoi posso aiutarti a:

- Configurare un DB PostgreSQL su Heroku  
- Automatizzare il deploy con GitHub Actions  
- Gestire environment variables  

---

Buon lavoro! 🚀
